package net.webius.randomlunchfood;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RandomLunchFoodApplicationTests {

	@Test
	void contextLoads() {
	}

}
